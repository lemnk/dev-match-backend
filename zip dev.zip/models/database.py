from pymongo import MongoClient
from flask import current_app, g
from datetime import datetime
import os

def get_client():
    if 'mongo_client' not in g:
        g.mongo_client = MongoClient(current_app.config['MONGODB_URI'])
    return g.mongo_client

def get_db():
    if 'mongo_db' not in g:
        client = get_client()
        db_name = current_app.config['MONGODB_URI'].split('/')[-1].split('?')[0]
        if not db_name or db_name == '':
            db_name = 'devmatch'
        g.mongo_db = client[db_name]
    return g.mongo_db

def init_db(app):
    with app.app_context():
        db = get_db()
        db.users.create_index('email', unique=True)
        db.users.create_index('github_username')
        db.matches.create_index([('user_id', 1), ('created_at', -1)])
        db.bookmarks.create_index([('user_id', 1), ('matched_user_id', 1)], unique=True)

def close_db(e=None):
    client = g.pop('mongo_client', None)
    if client is not None:
        client.close()
    g.pop('mongo_db', None) 