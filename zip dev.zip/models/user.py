from models.database import get_db
from datetime import datetime
import bcrypt

class User:
    def __init__(self, email, password, github_username=None, bio=None):
        self.email = email
        self.password = password
        self.github_username = github_username
        self.bio = bio
        self.created_at = datetime.utcnow()
    
    def save(self):
        db = get_db()
        password_hash = bcrypt.hashpw(self.password.encode('utf-8'), bcrypt.gensalt())
        
        user_data = {
            'email': self.email,
            'password_hash': password_hash,
            'github_username': self.github_username,
            'bio': self.bio,
            'created_at': self.created_at
        }
        
        result = db.users.insert_one(user_data)
        user_data['_id'] = result.inserted_id
        return user_data
    
    @staticmethod
    def find_by_email(email):
        db = get_db()
        return db.users.find_one({'email': email})
    
    @staticmethod
    def find_by_id(user_id):
        db = get_db()
        return db.users.find_one({'_id': user_id})
    
    @staticmethod
    def find_by_github_username(github_username):
        db = get_db()
        return db.users.find_one({'github_username': github_username})
    
    @staticmethod
    def verify_password(password, password_hash):
        return bcrypt.checkpw(password.encode('utf-8'), password_hash)
    
    @staticmethod
    def update_github_info(user_id, github_username, bio):
        db = get_db()
        return db.users.update_one(
            {'_id': user_id},
            {'$set': {'github_username': github_username, 'bio': bio}}
        ) 