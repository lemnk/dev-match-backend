from models.database import get_db
from datetime import datetime

class Bookmark:
    def __init__(self, user_id, matched_user_id):
        self.user_id = user_id
        self.matched_user_id = matched_user_id
        self.created_at = datetime.utcnow()
    
    def save(self):
        db = get_db()
        bookmark_data = {
            'user_id': self.user_id,
            'matched_user_id': self.matched_user_id,
            'created_at': self.created_at
        }
        
        result = db.bookmarks.insert_one(bookmark_data)
        bookmark_data['_id'] = result.inserted_id
        return bookmark_data
    
    @staticmethod
    def find_by_user_id(user_id):
        db = get_db()
        return list(db.bookmarks.find({'user_id': user_id}).sort('created_at', -1))
    
    @staticmethod
    def find_existing_bookmark(user_id, matched_user_id):
        db = get_db()
        return db.bookmarks.find_one({
            'user_id': user_id,
            'matched_user_id': matched_user_id
        })
    
    @staticmethod
    def remove_bookmark(user_id, matched_user_id):
        db = get_db()
        return db.bookmarks.delete_one({
            'user_id': user_id,
            'matched_user_id': matched_user_id
        }) 