from models.database import get_db
from datetime import datetime
from bson import ObjectId

class Match:
    def __init__(self, user_id, matched_user_id, match_score, explanation):
        self.user_id = user_id
        self.matched_user_id = matched_user_id
        self.match_score = match_score
        self.explanation = explanation
        self.created_at = datetime.utcnow()
    
    def save(self):
        db = get_db()
        match_data = {
            'user_id': self.user_id,
            'matched_user_id': self.matched_user_id,
            'match_score': self.match_score,
            'explanation': self.explanation,
            'created_at': self.created_at
        }
        
        result = db.matches.insert_one(match_data)
        match_data['_id'] = result.inserted_id
        return match_data
    
    @staticmethod
    def find_by_user_id(user_id, limit=10):
        db = get_db()
        return list(db.matches.find(
            {'user_id': user_id}
        ).sort('match_score', -1).limit(limit))
    
    @staticmethod
    def find_existing_match(user_id, matched_user_id):
        db = get_db()
        return db.matches.find_one({
            'user_id': user_id,
            'matched_user_id': matched_user_id
        })
    
    @staticmethod
    def update_match(user_id, matched_user_id, match_score, explanation):
        db = get_db()
        return db.matches.update_one(
            {
                'user_id': user_id,
                'matched_user_id': matched_user_id
            },
            {
                '$set': {
                    'match_score': match_score,
                    'explanation': explanation,
                    'created_at': datetime.utcnow()
                }
            }
        ) 