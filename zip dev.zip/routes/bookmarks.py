from flask import Blueprint, request, jsonify
from models.bookmark import Bookmark
from models.user import User
from utils.jwt_helper import token_required
from bson import ObjectId

bookmarks_bp = Blueprint('bookmarks', __name__)

@bookmarks_bp.route('/bookmark/<user_id>', methods=['POST'])
@token_required
def bookmark_user(user_id):
    try:
        # Validate user_id format
        try:
            ObjectId(user_id)
        except:
            return jsonify({'error': 'Invalid user ID format'}), 400
        
        # Check if user exists
        user_to_bookmark = User.find_by_id(user_id)
        if not user_to_bookmark:
            return jsonify({'error': 'User not found'}), 404
        
        # Check if already bookmarked
        existing_bookmark = Bookmark.find_existing_bookmark(
            request.current_user['_id'], 
            user_id
        )
        
        if existing_bookmark:
            return jsonify({'error': 'User already bookmarked'}), 409
        
        # Create bookmark
        bookmark = Bookmark(request.current_user['_id'], user_id)
        bookmark_data = bookmark.save()
        
        return jsonify({
            'message': 'User bookmarked successfully',
            'bookmark_id': str(bookmark_data['_id'])
        }), 201
        
    except Exception as e:
        return jsonify({'error': f'Failed to bookmark user: {str(e)}'}), 500

@bookmarks_bp.route('/bookmark/<user_id>', methods=['DELETE'])
@token_required
def remove_bookmark(user_id):
    try:
        # Validate user_id format
        try:
            ObjectId(user_id)
        except:
            return jsonify({'error': 'Invalid user ID format'}), 400
        
        # Remove bookmark
        result = Bookmark.remove_bookmark(request.current_user['_id'], user_id)
        
        if result.deleted_count == 0:
            return jsonify({'error': 'Bookmark not found'}), 404
        
        return jsonify({'message': 'Bookmark removed successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': f'Failed to remove bookmark: {str(e)}'}), 500

@bookmarks_bp.route('/bookmarks', methods=['GET'])
@token_required
def get_bookmarks():
    try:
        # Get user's bookmarks
        bookmarks = Bookmark.find_by_user_id(request.current_user['_id'])
        
        # Enrich bookmarks with user data
        enriched_bookmarks = []
        
        for bookmark in bookmarks:
            bookmarked_user = User.find_by_id(bookmark['matched_user_id'])
            if bookmarked_user:
                enriched_bookmarks.append({
                    'bookmark_id': str(bookmark['_id']),
                    'user_id': str(bookmarked_user['_id']),
                    'email': bookmarked_user['email'],
                    'github_username': bookmarked_user.get('github_username', ''),
                    'bio': bookmarked_user.get('bio', ''),
                    'created_at': bookmark['created_at'].isoformat()
                })
        
        return jsonify({
            'bookmarks': enriched_bookmarks,
            'total_bookmarks': len(enriched_bookmarks)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Failed to retrieve bookmarks: {str(e)}'}), 500 