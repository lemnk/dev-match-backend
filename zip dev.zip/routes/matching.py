from flask import Blueprint, request, jsonify
from models.user import User
from models.match import Match
from utils.jwt_helper import token_required
from utils.github_api import get_user_repos, extract_skills_from_repos
from utils.openai_helper import extract_skills_from_bio_and_repos, calculate_match_score
from models.database import get_db
from bson import ObjectId
from html import escape

matching_bp = Blueprint('matching', __name__)

def validate_bio(bio):
    """Validate bio length and content"""
    # Sanitize bio to prevent XSS
    bio = escape(bio.strip())
    
    if not bio or len(bio) < 10:
        return False, "Bio must be at least 10 characters long"
    if len(bio) > 500:
        return False, "Bio must be less than 500 characters"
    return True, bio

@matching_bp.route('/analyze', methods=['POST'])
@token_required
def analyze_profile():
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        github_username = data.get('github_username', '').strip()
        bio = data.get('bio', '').strip()
        
        # Validation
        if not github_username:
            return jsonify({'error': 'GitHub username is required'}), 400
        
        is_valid, bio_result = validate_bio(bio)
        if not is_valid:
            return jsonify({'error': bio_result}), 400
        
        # Use sanitized bio
        sanitized_bio = bio_result
        
        # Update user's GitHub info
        User.update_github_info(request.current_user['_id'], github_username, sanitized_bio)
        
        # Fetch GitHub repositories
        try:
            repos_data = get_user_repos(github_username)
        except ValueError as e:
            return jsonify({'error': str(e)}), 400
        
        # Extract skills using OpenAI
        try:
            user_skills = extract_skills_from_bio_and_repos(sanitized_bio, repos_data)
        except ValueError as e:
            return jsonify({'error': str(e)}), 500
        
        # Find other users in the database
        db = get_db()
        other_users = list(db.users.find({
            '_id': {'$ne': request.current_user['_id']},
            'github_username': {'$exists': True, '$ne': None}
        }))
        
        matches = []
        
        # Calculate matches with other users
        for other_user in other_users[:20]:  # Limit to 20 users for performance
            try:
                # Get other user's repositories
                other_repos = get_user_repos(other_user['github_username'])
                other_skills = extract_skills_from_bio_and_repos(other_user.get('bio', ''), other_repos)
                
                # Calculate match score
                match_result = calculate_match_score(user_skills, other_skills)
                
                if match_result and 'match_score' in match_result:
                    match_score = match_result['match_score']
                    explanation = match_result.get('explanation', 'No explanation available')
                    
                    # Store or update match in database
                    existing_match = Match.find_existing_match(
                        request.current_user['_id'], 
                        other_user['_id']
                    )
                    
                    if existing_match:
                        Match.update_match(
                            request.current_user['_id'],
                            other_user['_id'],
                            match_score,
                            explanation
                        )
                    else:
                        match = Match(
                            request.current_user['_id'],
                            other_user['_id'],
                            match_score,
                            explanation
                        )
                        match.save()
                    
                    matches.append({
                        'user_id': str(other_user['_id']),
                        'email': other_user['email'],
                        'github_username': other_user['github_username'],
                        'bio': other_user.get('bio', ''),
                        'match_score': match_score,
                        'explanation': explanation
                    })
                    
            except Exception as e:
                # Skip users with errors, continue with others
                continue
        
        # Sort matches by score and return top 5
        matches.sort(key=lambda x: x['match_score'], reverse=True)
        top_matches = matches[:5]
        
        return jsonify({
            'message': 'Profile analyzed successfully',
            'matches': top_matches,
            'total_users_analyzed': len(other_users)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

@matching_bp.route('/matches', methods=['GET'])
@token_required
def get_matches():
    try:
        # Get user's matches from database
        matches = Match.find_by_user_id(request.current_user['_id'], limit=20)
        
        # Enrich matches with user data
        enriched_matches = []
        db = get_db()
        
        for match in matches:
            matched_user = User.find_by_id(match['matched_user_id'])
            if matched_user:
                enriched_matches.append({
                    'match_id': str(match['_id']),
                    'user_id': str(matched_user['_id']),
                    'email': matched_user['email'],
                    'github_username': matched_user.get('github_username', ''),
                    'bio': matched_user.get('bio', ''),
                    'match_score': match['match_score'],
                    'explanation': match['explanation'],
                    'created_at': match['created_at'].isoformat()
                })
        
        return jsonify({
            'matches': enriched_matches,
            'total_matches': len(enriched_matches)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Failed to retrieve matches: {str(e)}'}), 500 