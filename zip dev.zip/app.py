from flask import Flask
from flask_cors import CORS
from routes.auth import auth_bp
from routes.matching import matching_bp
from routes.bookmarks import bookmarks_bp
from models.database import init_db, close_db
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['MONGODB_URI'] = os.environ.get('MONGODB_URI', 'mongodb://localhost:27017/devmatch')
    app.config['OPENAI_API_KEY'] = os.environ.get('OPENAI_API_KEY')
    app.config['GITHUB_TOKEN'] = os.environ.get('GITHUB_TOKEN')
    
    # Initialize CORS
    CORS(app)
    
    # Validate required environment variables
    required_envs = ['SECRET_KEY', 'MONGODB_URI', 'OPENAI_API_KEY']
    for env in required_envs:
        if not app.config.get(env):
            raise ValueError(f"Missing required environment variable: {env}")
    
    # Initialize database
    init_db(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api')
    app.register_blueprint(matching_bp, url_prefix='/api')
    app.register_blueprint(bookmarks_bp, url_prefix='/api')
    
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'message': 'DevMatch AI is running'}
    
    @app.teardown_appcontext
    def teardown_db(exception):
        if not app.config.get('TESTING'):
            close_db()
    
    @app.after_request
    def add_security_headers(response):
        response.headers['Content-Security-Policy'] = "default-src 'self'"
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        return response
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000))) 