import pytest
import json
from app import create_app
from models.database import get_db, init_db

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['MONGODB_URI'] = 'mongodb+srv://naolzed:18BOD9WLcVycNnIW@cluster0.15qkutm.mongodb.net/devmatch_test?retryWrites=true&w=majority&appName=Cluster0'
    app.config['OPENAI_API_KEY'] = 'test-key'
    app.config['GITHUB_TOKEN'] = 'test-token'
    app.config['SECRET_KEY'] = 'test-secret-key'
    
    with app.test_client() as client:
        with app.app_context():
            # Re-initialize DB for each test context
            init_db(app)
            db = get_db()
            db.users.delete_many({})
            db.matches.delete_many({})
            db.bookmarks.delete_many({})
        yield client

def test_signup_success(client):
    """Test successful user registration"""
    data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    
    response = client.post('/api/signup', 
                          data=json.dumps(data),
                          content_type='application/json')
    
    assert response.status_code == 201
    result = json.loads(response.data)
    assert 'token' in result
    assert 'user' in result
    assert result['user']['email'] == 'test@example.com'

def test_signup_invalid_email(client):
    """Test registration with invalid email"""
    data = {
        'email': 'invalid-email',
        'password': 'password123'
    }
    
    response = client.post('/api/signup',
                          data=json.dumps(data),
                          content_type='application/json')
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_signup_weak_password(client):
    """Test registration with weak password"""
    data = {
        'email': 'test@example.com',
        'password': '123'
    }
    
    response = client.post('/api/signup',
                          data=json.dumps(data),
                          content_type='application/json')
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_signup_duplicate_email(client):
    """Test registration with duplicate email"""
    data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    
    # First registration
    client.post('/api/signup',
                data=json.dumps(data),
                content_type='application/json')
    
    # Second registration with same email
    response = client.post('/api/signup',
                          data=json.dumps(data),
                          content_type='application/json')
    
    assert response.status_code == 409
    result = json.loads(response.data)
    assert 'error' in result

def test_login_success(client):
    """Test successful login"""
    # First register a user
    signup_data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    client.post('/api/signup',
                data=json.dumps(signup_data),
                content_type='application/json')
    
    # Then login
    login_data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    
    response = client.post('/api/login',
                          data=json.dumps(login_data),
                          content_type='application/json')
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'token' in result
    assert 'user' in result

def test_login_invalid_credentials(client):
    """Test login with invalid credentials"""
    data = {
        'email': 'test@example.com',
        'password': 'wrongpassword'
    }
    
    response = client.post('/api/login',
                          data=json.dumps(data),
                          content_type='application/json')
    
    assert response.status_code == 401
    result = json.loads(response.data)
    assert 'error' in result 