import pytest
import json
from unittest.mock import patch, MagicMock
from app import create_app
from models.database import get_db, init_db
from models.user import User

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['MONGODB_URI'] = 'mongodb+srv://naolzed:18BOD9WLcVycNnIW@cluster0.15qkutm.mongodb.net/devmatch_test?retryWrites=true&w=majority&appName=Cluster0'
    app.config['OPENAI_API_KEY'] = 'test-key'
    app.config['GITHUB_TOKEN'] = 'test-token'
    app.config['SECRET_KEY'] = 'test-secret-key'
    
    with app.test_client() as client:
        with app.app_context():
            # Re-initialize DB for each test context
            init_db(app)
            db = get_db()
            db.users.delete_many({})
            db.matches.delete_many({})
            db.bookmarks.delete_many({})
        yield client

@pytest.fixture
def auth_token(client):
    """Create a user and return auth token"""
    # Register user
    signup_data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    response = client.post('/api/signup',
                          data=json.dumps(signup_data),
                          content_type='application/json')
    result = json.loads(response.data)
    return result['token']

@pytest.fixture
def other_user_id(client):
    """Create another user and return their ID"""
    # Register another user
    signup_data = {
        'email': 'other@example.com',
        'password': 'password123'
    }
    response = client.post('/api/signup',
                          data=json.dumps(signup_data),
                          content_type='application/json')
    result = json.loads(response.data)
    return result['user']['id']

def test_bookmark_user_success(client, auth_token, other_user_id):
    """Test successful bookmark creation"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.post(f'/api/bookmark/{other_user_id}',
                          headers=headers)
    
    assert response.status_code == 201
    result = json.loads(response.data)
    assert 'bookmark_id' in result
    assert 'message' in result
    assert result['message'] == 'User bookmarked successfully'

def test_bookmark_user_invalid_id(client, auth_token):
    """Test bookmark with invalid user ID"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.post('/api/bookmark/invalid-id',
                          headers=headers)
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_bookmark_nonexistent_user(client, auth_token):
    """Test bookmarking a user that doesn't exist"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    # Use a fake ObjectId
    fake_id = '507f1f77bcf86cd799439011'
    
    response = client.post(f'/api/bookmark/{fake_id}',
                          headers=headers)
    
    assert response.status_code == 404
    result = json.loads(response.data)
    assert 'error' in result

def test_bookmark_duplicate(client, auth_token, other_user_id):
    """Test bookmarking the same user twice"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    # First bookmark
    response1 = client.post(f'/api/bookmark/{other_user_id}',
                           headers=headers)
    assert response1.status_code == 201
    
    # Second bookmark (should fail)
    response2 = client.post(f'/api/bookmark/{other_user_id}',
                           headers=headers)
    assert response2.status_code == 409
    result = json.loads(response2.data)
    assert 'error' in result

def test_bookmark_unauthorized(client, other_user_id):
    """Test bookmark without authentication"""
    response = client.post(f'/api/bookmark/{other_user_id}')
    
    assert response.status_code == 401
    result = json.loads(response.data)
    assert 'message' in result

def test_remove_bookmark_success(client, auth_token, other_user_id):
    """Test successful bookmark removal"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    # First create a bookmark
    client.post(f'/api/bookmark/{other_user_id}',
                headers=headers)
    
    # Then remove it
    response = client.delete(f'/api/bookmark/{other_user_id}',
                            headers=headers)
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'message' in result
    assert result['message'] == 'Bookmark removed successfully'

def test_remove_bookmark_not_found(client, auth_token):
    """Test removing a bookmark that doesn't exist"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    # Use a fake ObjectId
    fake_id = '507f1f77bcf86cd799439011'
    
    response = client.delete(f'/api/bookmark/{fake_id}',
                            headers=headers)
    
    assert response.status_code == 404
    result = json.loads(response.data)
    assert 'error' in result

def test_remove_bookmark_invalid_id(client, auth_token):
    """Test removing bookmark with invalid ID"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.delete('/api/bookmark/invalid-id',
                            headers=headers)
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_get_bookmarks_empty(client, auth_token):
    """Test getting bookmarks when user has none"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.get('/api/bookmarks',
                         headers=headers)
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'bookmarks' in result
    assert 'total_bookmarks' in result
    assert result['total_bookmarks'] == 0
    assert len(result['bookmarks']) == 0

def test_get_bookmarks_with_data(client, auth_token, other_user_id):
    """Test getting bookmarks when user has bookmarks"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    # Create a bookmark
    client.post(f'/api/bookmark/{other_user_id}',
                headers=headers)
    
    # Get bookmarks
    response = client.get('/api/bookmarks',
                         headers=headers)
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'bookmarks' in result
    assert 'total_bookmarks' in result
    assert result['total_bookmarks'] == 1
    assert len(result['bookmarks']) == 1
    
    # Check bookmark data
    bookmark = result['bookmarks'][0]
    assert 'bookmark_id' in bookmark
    assert 'user_id' in bookmark
    assert 'email' in bookmark
    assert bookmark['email'] == 'other@example.com'

def test_get_bookmarks_unauthorized(client):
    """Test getting bookmarks without authentication"""
    response = client.get('/api/bookmarks')
    
    assert response.status_code == 401
    result = json.loads(response.data)
    assert 'message' in result 