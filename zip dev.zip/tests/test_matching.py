import pytest
import json
from unittest.mock import patch, MagicMock
from app import create_app
from models.database import get_db, init_db
from models.user import User

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['MONGODB_URI'] = 'mongodb+srv://naolzed:18BOD9WLcVycNnIW@cluster0.15qkutm.mongodb.net/devmatch_test?retryWrites=true&w=majority&appName=Cluster0'
    app.config['OPENAI_API_KEY'] = 'test-key'
    app.config['GITHUB_TOKEN'] = 'test-token'
    app.config['SECRET_KEY'] = 'test-secret-key'
    
    with app.test_client() as client:
        with app.app_context():
            # Re-initialize DB for each test context
            init_db(app)
            db = get_db()
            db.users.delete_many({})
            db.matches.delete_many({})
            db.bookmarks.delete_many({})
        yield client

@pytest.fixture
def auth_token(client):
    """Create a user and return auth token"""
    # Register user
    signup_data = {
        'email': 'test@example.com',
        'password': 'password123'
    }
    response = client.post('/api/signup',
                          data=json.dumps(signup_data),
                          content_type='application/json')
    result = json.loads(response.data)
    return result['token']

def test_analyze_profile_missing_data(client, auth_token):
    """Test analyze endpoint with missing data"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.post('/api/analyze',
                          data=json.dumps({}),
                          content_type='application/json',
                          headers=headers)
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_analyze_profile_invalid_bio(client, auth_token):
    """Test analyze endpoint with invalid bio"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    data = {
        'github_username': 'testuser',
        'bio': 'short'
    }
    
    response = client.post('/api/analyze',
                          data=json.dumps(data),
                          content_type='application/json',
                          headers=headers)
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

@patch('utils.github_api.get_user_repos')
@patch('utils.openai_helper.extract_skills_from_bio_and_repos')
@patch('utils.openai_helper.calculate_match_score')
def test_analyze_profile_success(mock_calculate_score, mock_extract_skills, mock_get_repos, client, auth_token):
    """Test successful profile analysis"""
    # Mock GitHub API response
    mock_get_repos.return_value = [
        {
            'name': 'test-repo',
            'description': 'A test repository',
            'language': 'Python',
            'topics': ['flask', 'api'],
            'stars': 10,
            'forks': 5
        }
    ]
    
    # Mock OpenAI responses
    mock_extract_skills.return_value = {
        'skills': {
            'programming_languages': ['Python', 'JavaScript'],
            'frameworks': ['Flask', 'React'],
            'databases': ['MongoDB'],
            'cloud_platforms': ['AWS'],
            'tools': ['Git', 'Docker'],
            'domains': ['Web Development']
        },
        'experience_level': 'mid',
        'specializations': ['Backend Development']
    }
    
    mock_calculate_score.return_value = {
        'match_score': 85,
        'explanation': 'Great skill overlap in Python and web development'
    }
    
    headers = {'Authorization': f'Bearer {auth_token}'}
    data = {
        'github_username': 'testuser',
        'bio': 'I am a Python developer with experience in Flask and web development. I love building scalable APIs and working with modern technologies.'
    }
    
    response = client.post('/api/analyze',
                          data=json.dumps(data),
                          content_type='application/json',
                          headers=headers)
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'matches' in result
    assert 'message' in result

@patch('utils.github_api.get_user_repos')
def test_analyze_profile_github_error(mock_get_repos, client, auth_token):
    """Test analyze endpoint with GitHub API error"""
    mock_get_repos.side_effect = ValueError("GitHub user 'testuser' not found")
    
    headers = {'Authorization': f'Bearer {auth_token}'}
    data = {
        'github_username': 'testuser',
        'bio': 'I am a Python developer with experience in Flask and web development.'
    }
    
    response = client.post('/api/analyze',
                          data=json.dumps(data),
                          content_type='application/json',
                          headers=headers)
    
    assert response.status_code == 400
    result = json.loads(response.data)
    assert 'error' in result

def test_get_matches_unauthorized(client):
    """Test get matches without authentication"""
    response = client.get('/api/matches')
    assert response.status_code == 401

def test_get_matches_success(client, auth_token):
    """Test successful retrieval of matches"""
    headers = {'Authorization': f'Bearer {auth_token}'}
    
    response = client.get('/api/matches', headers=headers)
    
    assert response.status_code == 200
    result = json.loads(response.data)
    assert 'matches' in result
    assert 'total_matches' in result 