#!/usr/bin/env python3
"""
Simple test runner for DevMatch AI
"""
import subprocess
import sys
import os

def run_tests():
    """Run the test suite"""
    try:
        # Check if pytest is installed
        import pytest
        print("Running tests...")
        
        # Run tests with verbose output
        result = subprocess.run([
            sys.executable, "-m", "pytest", 
            "tests/", "-v", "--tb=short"
        ], capture_output=True, text=True)
        
        print(result.stdout)
        if result.stderr:
            print("Errors:", result.stderr)
        
        return result.returncode == 0
        
    except ImportError:
        print("pytest not found. Installing...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pytest"])
        return run_tests()

if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1) 