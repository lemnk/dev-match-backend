# DevMatch AI

A Flask-based backend application that matches developers based on their GitHub activity and bio using AI-powered skill analysis.

## Features

- **User Authentication**: Secure JWT-based authentication with bcrypt password hashing
- **GitHub Integration**: Fetches user repositories and analyzes programming languages, frameworks, and technologies
- **AI-Powered Matching**: Uses OpenAI GPT-4 to extract skills and calculate compatibility scores
- **Match Management**: Store and retrieve user matches with detailed explanations
- **Bookmarking System**: Save interesting matches for later reference
- **RESTful API**: Clean, well-documented API endpoints
- **MongoDB Integration**: Scalable NoSQL database for user data and matches
- **Docker Support**: Containerized deployment ready
- **Unit Tests**: Comprehensive test coverage for core functionality

## Tech Stack

- **Backend**: Flask 2.3.3
- **Database**: MongoDB with PyMongo
- **Authentication**: JWT (PyJWT) with bcrypt
- **AI Integration**: OpenAI GPT-4 API
- **External APIs**: GitHub REST API
- **Testing**: pytest
- **Deployment**: Docker, Gunicorn
- **CORS**: Flask-CORS

## API Endpoints

### Authentication
- `POST /api/signup` - Register a new user
- `POST /api/login` - Authenticate user and get JWT token

### Profile Analysis & Matching
- `POST /api/analyze` - Analyze GitHub profile and find matches
- `GET /api/matches` - Get user's previous matches

### Bookmarks
- `POST /api/bookmark/:id` - Bookmark a user
- `DELETE /api/bookmark/:id` - Remove bookmark
- `GET /api/bookmarks` - Get user's bookmarks

### Health Check
- `GET /health` - Application health status

## Database Schema

### Users Collection
```json
{
  "_id": "ObjectId",
  "email": "string",
  "password_hash": "string",
  "github_username": "string",
  "bio": "string",
  "created_at": "datetime"
}
```

### Matches Collection
```json
{
  "_id": "ObjectId",
  "user_id": "ObjectId",
  "matched_user_id": "ObjectId",
  "match_score": "number (0-100)",
  "explanation": "string",
  "created_at": "datetime"
}
```

### Bookmarks Collection
```json
{
  "_id": "ObjectId",
  "user_id": "ObjectId",
  "matched_user_id": "ObjectId",
  "created_at": "datetime"
}
```

## Setup Instructions

### Prerequisites
- Python 3.11+
- MongoDB (local or cloud)
- OpenAI API key
- GitHub Personal Access Token (optional, for higher rate limits)

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd devmatch-ai
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   cp env.example .env
   # Edit .env with your actual values
   ```

5. **Start MongoDB**
   ```bash
   # If using local MongoDB
   mongod
   ```

6. **Run the application**
   ```bash
   python app.py
   ```

### Docker Deployment

1. **Build the image**
   ```bash
   docker build -t devmatch-ai .
   ```

2. **Run the container**
   ```bash
   docker run -p 5000:5000 --env-file .env devmatch-ai
   ```

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `SECRET_KEY` | Flask secret key for JWT signing | Yes |
| `MONGODB_URI` | MongoDB connection string | Yes |
| `OPENAI_API_KEY` | OpenAI API key for GPT-4 access | Yes |
| `GITHUB_TOKEN` | GitHub Personal Access Token | No |
| `PORT` | Application port (default: 5000) | No |

## API Usage Examples

### User Registration
```bash
curl -X POST http://localhost:5000/api/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "developer@example.com",
    "password": "securepassword123"
  }'
```

### User Login
```bash
curl -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "developer@example.com",
    "password": "securepassword123"
  }'
```

### Analyze Profile
```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "github_username": "octocat",
    "bio": "I am a full-stack developer with 5 years of experience in Python, JavaScript, and React. I specialize in building scalable web applications and APIs. I love contributing to open source projects and learning new technologies."
  }'
```

### Get Matches
```bash
curl -X GET http://localhost:5000/api/matches \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Bookmark a User
```bash
curl -X POST http://localhost:5000/api/bookmark/USER_ID \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

## Testing

Run the test suite:
```bash
pytest tests/
```

Run with coverage:
```bash
pytest --cov=. tests/
```

## Deployment on Render

1. **Connect your repository** to Render
2. **Create a new Web Service**
3. **Configure environment variables**:
   - `SECRET_KEY`: Generate a secure random key
   - `MONGODB_URI`: Your MongoDB connection string
   - `OPENAI_API_KEY`: Your OpenAI API key
   - `GITHUB_TOKEN`: Your GitHub token (optional)
4. **Set build command**: `pip install -r requirements.txt`
5. **Set start command**: `gunicorn --bind 0.0.0.0:$PORT app:create_app()`

## Error Handling

The application includes comprehensive error handling for:
- Invalid GitHub usernames (404)
- GitHub API rate limits (429)
- OpenAI API errors
- Invalid input validation
- Authentication failures
- Database connection issues

## Security Features

- **Password Hashing**: bcrypt with salt
- **JWT Authentication**: Secure token-based auth
- **Input Validation**: Email format, password strength, bio length
- **CORS Protection**: Configurable cross-origin requests
- **Rate Limiting**: Built-in protection against abuse
- **Error Sanitization**: No sensitive data in error messages

## Performance Considerations

- **Database Indexing**: Optimized indexes on frequently queried fields
- **API Rate Limiting**: Respects GitHub and OpenAI rate limits
- **Connection Pooling**: Efficient database connections
- **Caching**: Consider Redis for production caching
- **Async Processing**: Background tasks for heavy operations

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
- Create an issue in the repository
- Check the API documentation
- Review the test cases for usage examples 