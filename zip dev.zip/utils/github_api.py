import requests
from flask import current_app
import time
from cachetools import TTLCache

# Cache for GitHub API responses (24-hour TTL, max 100 entries)
github_cache = TTLCache(maxsize=100, ttl=86400)

def get_user_repos(username):
    """Fetch user repositories from GitHub API"""
    # Check cache first
    if username in github_cache:
        return github_cache[username]
    
    headers = {}
    if current_app.config.get('GITHUB_TOKEN'):
        headers['Authorization'] = f'token {current_app.config["GITHUB_TOKEN"]}'
    
    url = f'https://api.github.com/users/{username}/repos'
    
    try:
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 404:
            raise ValueError(f"GitHub user '{username}' not found")
        elif response.status_code == 403:
            raise ValueError("GitHub API rate limit exceeded. Please try again later.")
        elif response.status_code != 200:
            raise ValueError(f"GitHub API error: {response.status_code}")
        
        repos = response.json()
        
        # Extract relevant data from repositories
        repo_data = []
        for repo in repos[:20]:  # Limit to 20 most recent repos
            if not repo['fork']:  # Skip forked repositories
                repo_info = {
                    'name': repo['name'],
                    'description': repo['description'] or '',
                    'language': repo['language'],
                    'topics': repo.get('topics', []),
                    'stars': repo['stargazers_count'],
                    'forks': repo['forks_count']
                }
                repo_data.append(repo_info)
        
        # Cache the result
        github_cache[username] = repo_data
        return repo_data
        
    except requests.exceptions.Timeout:
        raise ValueError("GitHub API request timed out")
    except requests.exceptions.RequestException as e:
        raise ValueError(f"Error connecting to GitHub API: {str(e)}")

def extract_skills_from_repos(repos):
    """Extract skills from repository data"""
    skills = {
        'languages': set(),
        'technologies': set(),
        'topics': set()
    }
    
    for repo in repos:
        if repo['language']:
            skills['languages'].add(repo['language'])
        
        if repo['topics']:
            skills['topics'].update(repo['topics'])
        
        # Extract technologies from description
        description = repo['description'].lower() if repo['description'] else ''
        tech_keywords = ['react', 'vue', 'angular', 'node.js', 'django', 'flask', 'express', 
                        'mongodb', 'postgresql', 'mysql', 'redis', 'docker', 'kubernetes',
                        'aws', 'azure', 'gcp', 'terraform', 'jenkins', 'gitlab', 'github actions']
        
        for tech in tech_keywords:
            if tech in description:
                skills['technologies'].add(tech)
    
    return {
        'languages': list(skills['languages']),
        'technologies': list(skills['technologies']),
        'topics': list(skills['topics'])
    } 