from openai import OpenAI
from flask import current_app
import json

def extract_skills_from_bio_and_repos(bio, repos_data):
    """Use OpenAI GPT-4 to extract skills from bio and repository data"""
    if not current_app.config.get('OPENAI_API_KEY'):
        raise ValueError("OpenAI API key not configured")
    
    client = OpenAI(api_key=current_app.config['OPENAI_API_KEY'])
    
    # Prepare repository information
    repos_summary = []
    for repo in repos_data[:10]:  # Limit to 10 repos for token efficiency
        repo_info = f"Repo: {repo['name']}"
        if repo['description']:
            repo_info += f" - {repo['description']}"
        if repo['language']:
            repo_info += f" (Language: {repo['language']})"
        if repo['topics']:
            repo_info += f" (Topics: {', '.join(repo['topics'])})"
        repos_summary.append(repo_info)
    
    repos_text = "\n".join(repos_summary)
    
    prompt = f"""
    Analyze the following developer's bio and GitHub repositories to extract their technical skills and expertise.
    
    Bio: {bio}
    
    Recent Repositories:
    {repos_text}
    
    Please extract and return a JSON object with the following structure:
    {{
        "skills": {{
            "programming_languages": ["list", "of", "languages"],
            "frameworks": ["list", "of", "frameworks"],
            "databases": ["list", "of", "databases"],
            "cloud_platforms": ["list", "of", "cloud", "platforms"],
            "tools": ["list", "of", "development", "tools"],
            "domains": ["list", "of", "domain", "expertise"]
        }},
        "experience_level": "junior|mid|senior",
        "specializations": ["list", "of", "specializations"]
    }}
    
    Focus on concrete, technical skills that would be relevant for matching with other developers.
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a technical recruiter analyzing developer profiles. Extract specific, actionable skills from the provided information."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.3
        )
        
        content = response.choices[0].message.content.strip()
        
        # Extract JSON from response
        try:
            skills_data = json.loads(content)
            return skills_data
        except json.JSONDecodeError:
            # Fallback: try to extract JSON from the response
            start_idx = content.find('{')
            end_idx = content.rfind('}') + 1
            if start_idx != -1 and end_idx != 0:
                json_str = content[start_idx:end_idx]
                return json.loads(json_str)
            else:
                raise ValueError("Failed to parse skills data from OpenAI response")
                
    except Exception as e:
        if "rate_limit" in str(e).lower():
            raise ValueError("OpenAI API rate limit exceeded. Please try again later.")
        else:
            raise ValueError(f"OpenAI API error: {str(e)}")

def calculate_match_score(user_skills, other_user_skills):
    """Use OpenAI to calculate match score between two users based on their skills"""
    if not current_app.config.get('OPENAI_API_KEY'):
        raise ValueError("OpenAI API key not configured")
    
    client = OpenAI(api_key=current_app.config['OPENAI_API_KEY'])
    
    prompt = f"""
    Compare the skills of two developers and calculate a match score (0-100) based on skill overlap and compatibility.
    
    Developer 1 Skills:
    {json.dumps(user_skills, indent=2)}
    
    Developer 2 Skills:
    {json.dumps(other_user_skills, indent=2)}
    
    Return a JSON object with:
    {{
        "match_score": <score 0-100>,
        "explanation": "<brief explanation of why they match well>"
    }}
    
    Consider:
    - Skill overlap (programming languages, frameworks, tools)
    - Complementary skills that would work well together
    - Experience level compatibility
    - Domain expertise alignment
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a technical recruiter evaluating developer compatibility. Provide accurate match scores and clear explanations."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=300,
            temperature=0.3
        )
        
        content = response.choices[0].message.content.strip()
        
        try:
            match_data = json.loads(content)
            return match_data
        except json.JSONDecodeError:
            # Fallback parsing
            start_idx = content.find('{')
            end_idx = content.rfind('}') + 1
            if start_idx != -1 and end_idx != 0:
                json_str = content[start_idx:end_idx]
                return json.loads(json_str)
            else:
                raise ValueError("Failed to parse match data from OpenAI response")
                
    except Exception as e:
        if "rate_limit" in str(e).lower():
            raise ValueError("OpenAI API rate limit exceeded. Please try again later.")
        else:
            raise ValueError(f"OpenAI API error: {str(e)}") 