#!/usr/bin/env python3
"""
Simple MongoDB connection test
"""
from pymongo import MongoClient
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_mongo_connection():
    """Test MongoDB connection"""
    try:
        # Get MongoDB URI from environment
        mongo_uri = os.getenv('MONGODB_URI')
        print(f"Testing connection to: {mongo_uri}")
        
        # Create client
        client = MongoClient(mongo_uri)
        
        # Test connection
        client.admin.command('ping')
        print("✅ MongoDB connection successful!")
        
        # List databases
        databases = client.list_database_names()
        print(f"Available databases: {databases}")
        
        # Close connection
        client.close()
        
    except Exception as e:
        print(f"❌ MongoDB connection failed: {e}")

if __name__ == "__main__":
    test_mongo_connection() 