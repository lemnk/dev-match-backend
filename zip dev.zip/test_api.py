#!/usr/bin/env python3
"""
Test script for DevMatch AI API
"""
import requests
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

BASE_URL = "http://localhost:5000"

def test_health():
    """Test health endpoint"""
    print("Testing health endpoint...")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

def test_signup():
    """Test user signup"""
    print("Testing user signup...")
    data = {
        "email": "test@example.com",
        "password": "password123"
    }
    response = requests.post(f"{BASE_URL}/api/signup", json=data)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()
    return response.json().get('token')

def test_login():
    """Test user login"""
    print("Testing user login...")
    data = {
        "email": "test@example.com",
        "password": "password123"
    }
    response = requests.post(f"{BASE_URL}/api/login", json=data)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()
    return response.json().get('token')

def test_analyze_profile(token):
    """Test profile analysis"""
    print("Testing profile analysis...")
    headers = {"Authorization": f"Bearer {token}"}
    data = {
        "github_username": "octocat",
        "bio": "I am a full-stack developer with 5 years of experience in Python, JavaScript, and React. I specialize in building scalable web applications and APIs. I love contributing to open source projects and learning new technologies."
    }
    response = requests.post(f"{BASE_URL}/api/analyze", json=data, headers=headers)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

def test_get_matches(token):
    """Test getting matches"""
    print("Testing get matches...")
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/api/matches", headers=headers)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

def main():
    """Run all tests"""
    print("=== DevMatch AI API Tests ===\n")
    
    # Test health
    test_health()
    
    # Test signup
    token = test_signup()
    
    if token:
        # Test analyze profile
        test_analyze_profile(token)
        
        # Test get matches
        test_get_matches(token)
    else:
        print("Failed to get token, skipping authenticated tests")

if __name__ == "__main__":
    main() 